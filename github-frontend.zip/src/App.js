import React, { useState } from 'react';
import './App.css';

function App() {
  const [videoUrl, setVideoUrl] = useState('');
  const [summary, setSummary] = useState('');
  const [script, setScript] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [mainImage, setMainImage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    const res = await fetch(process.env.REACT_APP_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: videoUrl })
    });
    const data = await res.json();
    setSummary(data.summary);
    setScript(data.script);
    setThumbnail(data.thumbnail);
    setMainImage(data.main_image);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-md p-6">
        <h1 className="text-2xl font-bold mb-4">🎥 YouTube Video to Script Web App</h1>

        <input
          type="text"
          placeholder="Enter YouTube video URL"
          className="w-full border rounded p-2 mb-4"
          value={videoUrl}
          onChange={(e) => setVideoUrl(e.target.value)}
        />

        <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded">
          {loading ? 'Processing...' : 'Get Script'}
        </button>

        {thumbnail && <img src={thumbnail} alt="Thumbnail" className="mt-4 rounded" />}
        {mainImage && <img src={mainImage} alt="Main topic" className="mt-4 rounded" />}

        {summary && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">🧠 Summary</h2>
            <p className="text-gray-800">{summary}</p>
          </div>
        )}

        {script && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">📜 Full Script</h2>
            <p className="text-gray-700 whitespace-pre-line">{script}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;